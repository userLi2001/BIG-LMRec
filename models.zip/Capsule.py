import torch
import torch.nn as nn


class CapsuleLayer(nn.Module):
    def __init__(self, args, init_std=1.0):
        super(CapsuleLayer, self).__init__()
        embed_dim = args.d_latent  # 输入特征维度（如行为嵌入的维度）
        self.k_max = args.k_max  # 兴趣簇数量
        self.iters = args.iters  # 动态路由的迭代次数（默认为3）
        self.init_std = init_std  # 参数初始化的标准差

        # Shared bilinear mapping matrix
        self.bilinear_mapping_matrix = nn.parameter.Parameter(
            nn.init.normal_(torch.Tensor(embed_dim, embed_dim), std=init_std),
            requires_grad=True,
        )

    @staticmethod
    def squash(inputs):
        vec_square_norm = torch.sum(torch.square(inputs), dim=-1, keepdim=True)
        scalar_factor = (
            vec_square_norm
            / (1.0 + vec_square_norm)
            / torch.sqrt(vec_square_norm + 1e-8)
        )
        vec_squashed = scalar_factor * inputs
        return vec_squashed

    def forward(self, behavior_embs):
        """
        Forward
            behavior_embs: [N, L, D]
            seq_len: [N, 1]
        """
        batch_size, max_len, _ = behavior_embs.shape
        device = behavior_embs.device  # 获取输入张量所在的设备

        # Step 1: 双线性映射
        behavior_mappings = torch.matmul(behavior_embs, self.bilinear_mapping_matrix)
        behavior_mappings_detached = behavior_mappings.detach()
        # Step 2: 初始化路由权重 [batch_size, k_max, seq_len]
        routing_logits = torch.normal(
            mean=0.0,
            std=self.init_std,
            size=(batch_size, self.k_max, max_len),
            device=device,
        )
        # Step 3: 动态路由迭代
        for _ in range(self.iters - 1):
            weights = torch.softmax(routing_logits, dim=1)
            candidates = torch.matmul(weights, behavior_mappings_detached)
            interests = self.squash(candidates)
            delta_routing_logits = torch.matmul(
                interests, behavior_mappings_detached.transpose(-2, -1)
            )
            routing_logits += delta_routing_logits

        weights = torch.softmax(routing_logits, dim=1)
        candidates = torch.matmul(weights, behavior_mappings)
        interests = self.squash(candidates)
        # note: return : B * max_interest* dim
        return interests
