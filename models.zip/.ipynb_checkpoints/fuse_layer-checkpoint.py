import torch
import torch.nn as nn
import torch.nn.functional as F


class AttentionPooling(nn.Module):
    def __init__(self, args):
        super().__init__()
        d_model = args.d_latent
        self.query_proj = nn.Linear(d_model, d_model)
        self.key_proj = nn.Linear(d_model, d_model)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, capsules, user_profile):
        """
        capsules: [B, k, D]       多兴趣表示
        user_profile: [B, D]      查询向量（如 h_sa_x 最后一个 token）
        return: [B, D]            加权兴趣向量
        """
        q = self.query_proj(user_profile).unsqueeze(1)  # [B, 1, D]
        k = self.key_proj(capsules)  # [B, k, D]

        scores = torch.bmm(q, k.transpose(1, 2)).squeeze(1)  # [B, k]
        weights = self.softmax(scores)  # [B, k]
        pooled = torch.bmm(weights.unsqueeze(1), capsules).squeeze(1)  # [B, D]
        return pooled


class ScaledDotProductAttention(nn.Module):
    def __init__(self):
        super().__init__()

    @staticmethod
    def forward(query, key, value, mask=None, dropout=None):
        # query/key/value: [B, H, L, d_k]
        assert (
            query.dim() == key.dim() == value.dim() == 4
        ), "Inputs must be [B, H, L, d_k]"

        d_k = query.size(-1)
        scores = torch.matmul(query, key.transpose(-2, -1)) / torch.math.sqrt(
            d_k
        )  # [B, H, L_q, L_k]

        if mask is not None:
            # Mask shape: [B, 1, L_q, L_k] or [B, H, L_q, L_k]
            scores = scores.masked_fill(mask == 1, float("-inf"))

        attn_weights = F.softmax(scores, dim=-1)
        if dropout is not None:
            attn_weights = dropout(attn_weights)

        output = torch.matmul(attn_weights, value)  # [B, H, L_q, d_k]
        return output, attn_weights


class CrossAttentionBlock(nn.Module):
    def __init__(self, args):
        super().__init__()
        args.d_latent = args.d_latent
        self.num_heads = args.n_head
        self.dropout = args.dropout

        self.d_k = args.d_latent // self.num_heads
        self.dropout = nn.Dropout(self.dropout)

        self.q_linear = nn.Linear(args.d_latent, args.d_latent)
        self.k_linear = nn.Linear(args.d_latent, args.d_latent)
        self.v_linear = nn.Linear(args.d_latent, args.d_latent)

        self.out_proj = nn.Linear(args.d_latent, args.d_latent)
        self.attention = ScaledDotProductAttention()

        self.norm = nn.LayerNorm(args.d_latent)

        self.device = args.device

    def forward(self, query, key, value):

        mask = torch.triu(torch.full((query.shape[1],
                                            key.shape[1]), True), diagonal=1).to(self.device)

        B, L_q, D = query.size()

        def shape(x, linear):
            x = linear(x).view(B, -1, self.num_heads, self.d_k)
            return x.transpose(1, 2)  # [B, H, L, d_k]

        q = shape(query, self.q_linear)
        k = shape(key, self.k_linear)
        v = shape(value, self.v_linear)

        if mask is not None:
            # Expected mask shape: [B, L_q, L_k] → [B, 1, L_q, L_k]
            if mask.dim() == 3:
                mask = mask.unsqueeze(1)

        attn_output, _ = self.attention(q, k, v, mask, self.dropout)  # [B, H, L_q, d_k]
        attn_output = (
            attn_output.transpose(1, 2).contiguous().view(B, L_q, D)
        )  # [B, L_q, D]
        output = self.out_proj(attn_output)

        # Add & Norm
        return self.norm(query + output)
