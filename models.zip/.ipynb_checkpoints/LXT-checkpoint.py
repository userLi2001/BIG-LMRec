import torch
import torch.nn as nn
import torch.nn.functional as F

from models.Capsule import CapsuleLayer
from models.encoders import (
    MultiHeadAttention,
    FeedForward,
    ItemEmbedding,
    PositionalEmbedding,
)
from models.fuse_layer import CrossAttentionBlock, AttentionPooling
from models.layers import MoEBlock
from utils.metrics import cal_norm_mask
from utils.misc import init_weights


class LXT(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.temp = args.temp
        self.num_experts = args.num_experts
        self.top_k = args.top_k
        self.rank = args.rank

        # item and positional embedding
        self.ei = ItemEmbedding(args.n_item + 1, args.d_latent)
        self.ep = PositionalEmbedding(args.len_trim, args.d_latent)

        # encoder, dlora
        self.mha = MultiHeadAttention(args)
        self.ffn = FeedForward(args.d_latent)
        self.dropout = nn.Dropout(args.dropout)

        self.norm_sa_x = nn.LayerNorm(args.d_latent)
        self.norm_sa_a = nn.LayerNorm(args.d_latent)
        self.norm_sa_b = nn.LayerNorm(args.d_latent)

        # MoeLora
        self.MoeLora_a = MoEBlock(
            d_latent=args.d_latent,
            num_experts=self.num_experts,
            top_k=self.top_k,
            dropout=args.dropout,
            rank=self.rank,
            layer_num=args.layer_num_a,
        )
        self.MoeLora_b = MoEBlock(
            d_latent=args.d_latent,
            num_experts=self.num_experts,
            top_k=self.top_k,
            dropout=args.dropout,
            rank=self.rank,
            layer_num=args.layer_num_b,
        )
        self.MoeLora_x = MoEBlock(
            d_latent=args.d_latent,
            num_experts=self.num_experts,
            top_k=self.top_k,
            dropout=args.dropout,
            rank=self.rank,
            layer_num=args.layer_num_x,
        )

        # Capsule
        self.Capsule = CapsuleLayer(args)
        # Cross_Domain Bridge
        self.CBD_a = CrossAttentionBlock(args)
        self.CBD_b = CrossAttentionBlock(args)
        self.attn_pooling = AttentionPooling(args)

        # proj
        self.proj_a = FeedForward(args.d_latent)
        self.proj_b = FeedForward(args.d_latent)

        self.norm_a2a = nn.LayerNorm(args.d_latent)
        self.norm_b2b = nn.LayerNorm(args.d_latent)
        self.norm_a2b = nn.LayerNorm(args.d_latent)

        self.apply(init_weights)

    def forward(
        self,
        seq_x,
        seq_a,
        seq_b,
        pos_x,
        pos_a,
        pos_b,
        mask_x,
        mask_a,
        mask_b,
        mask_gt_a,
        mask_gt_b,
    ):
        # embedding
        e_x = self.dropout((self.ei(seq_x) + self.ep(pos_x)) * mask_x)
        e_a = self.dropout((self.ei(seq_a) + self.ep(pos_a)) * mask_a)
        e_b = self.dropout((self.ei(seq_b) + self.ep(pos_b)) * mask_b)

        # mha
        h_sa_x = self.mha(e_x, mask_x)
        h_sa_a = self.mha(e_a, mask_a)
        h_sa_b = self.mha(e_b, mask_b)

        # switch training / evaluating
        if self.training:
            mask_gt_a = mask_gt_a.unsqueeze(-1)
            mask_gt_b = mask_gt_b.unsqueeze(-1)
        else:
            mask_x = mask_a = mask_b = 1
            mask_gt_a = mask_gt_a.unsqueeze(-1)
            mask_gt_b = mask_gt_b.unsqueeze(-1)

        # ffn
        h_sa_x = (
            self.norm_sa_x(
                h_sa_x
                + self.dropout(self.ffn(h_sa_x))
                + self.dropout(self.MoeLora_x(h_sa_x))
            )
            * mask_x
        )

        h_sa_a = (
            self.norm_sa_a(
                h_sa_a
                + self.dropout(self.ffn(h_sa_a))
                + self.dropout(self.MoeLora_a(h_sa_a))
                + self.dropout(h_sa_x)
            )
            * mask_a
        )

        h_sa_b = (
            self.norm_sa_b(
                h_sa_b
                + self.dropout(self.ffn(h_sa_b))
                + self.dropout(self.MoeLora_b(h_sa_b))
                + self.dropout(h_sa_x)
            )
            * mask_b
        )

        capsules = self.Capsule(h_sa_x)
        user_profile = h_sa_x[:, -1, :]

        p_i = self.attn_pooling(capsules, user_profile)

        h_a2a = self.norm_a2a(
            (
                h_sa_a
                + self.dropout(self.proj_a(h_sa_a))
                + self.dropout(p_i.unsqueeze(1))
            )
            * mask_gt_a
        )
        h_b2b = self.norm_b2b(
            (
                h_sa_b
                + self.dropout(self.proj_b(h_sa_b))
                + self.dropout(p_i.unsqueeze(1))
            )
            * mask_gt_b
        )
        h_a2a = self.norm_a2b(self.CBD_a(h_a2a, capsules, capsules) + self.CBD_a(h_sa_x, capsules, capsules))
        h_b2b = self.norm_a2b(self.CBD_b(h_b2b, capsules, capsules) + self.CBD_b(h_sa_x, capsules, capsules))

        h = h_a2a * mask_gt_a + h_b2b * mask_gt_b

        return h, h_sa_x, h_sa_a, h_sa_b

    def cal_rec_loss(self, h, gt, gt_neg, mask_gt_a, mask_gt_b):
        """InfoNCE"""
        e_gt = self.ei(gt)
        e_neg = self.ei(gt_neg)

        logits = torch.cat(
            ((h * e_gt).unsqueeze(-2).sum(-1), (h.unsqueeze(-2) * e_neg).sum(-1)),
            dim=-1,
        ).div(self.temp)

        loss = -F.log_softmax(logits, dim=2)[:, :, 0]
        loss_a = (loss * cal_norm_mask(mask_gt_a)).sum(-1).mean()
        loss_b = (loss * cal_norm_mask(mask_gt_b)).sum(-1).mean()
        return loss_a, loss_b

    @staticmethod
    def cal_domain_rank(h, e_gt, e_mtc, mask_gt_a, mask_gt_b):
        """calculate domain rank via inner-product similarity"""
        user_vec = h[:, -1, :]  # [B, D]
        logit_gt = (user_vec * e_gt.squeeze(1)).sum(-1, keepdim=True)
        logit_mtc = (e_mtc * user_vec.unsqueeze(1)).sum(-1)  # [B, N]

        ranks = (logit_mtc - logit_gt).gt(0).sum(-1).add(1)
        ranks_a = ranks[mask_gt_a == 1].tolist()
        ranks_b = ranks[mask_gt_b == 1].tolist()

        return ranks_a, ranks_b

    def cal_rank(self, h_f, h_c, h_a, h_b, gt, gt_mtc, mask_gt_a, mask_gt_b):
        """rank via inner-product similarity"""
        mask_gt_a = mask_gt_a.squeeze(-1)
        mask_gt_b = mask_gt_b.squeeze(-1)

        e_gt, e_mtc = self.ei(gt), self.ei(gt_mtc)

        ranks_f2a, ranks_f2b = self.cal_domain_rank(
            h_f, e_gt, e_mtc, mask_gt_a, mask_gt_b
        )
        ranks_c2a, ranks_c2b = self.cal_domain_rank(
            h_c, e_gt, e_mtc, mask_gt_a, mask_gt_b
        )
        ranks_a2a, ranks_a2b = self.cal_domain_rank(
            h_a, e_gt, e_mtc, mask_gt_a, mask_gt_b
        )
        ranks_b2a, ranks_b2b = self.cal_domain_rank(
            h_b, e_gt, e_mtc, mask_gt_a, mask_gt_b
        )

        return (
            ranks_f2a,
            ranks_f2b,
            ranks_c2a,
            ranks_c2b,
            ranks_a2a,
            ranks_a2b,
            ranks_b2a,
            ranks_b2b,
        )
